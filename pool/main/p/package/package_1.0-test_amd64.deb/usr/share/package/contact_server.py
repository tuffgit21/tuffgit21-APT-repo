import customtkinter as ctk
root = ctk.CTk()
root.geometry("300x300")
root.title("Hello")
text = ctk.CTkLabel(root,text="hello")
text.pack(pady=20)
root.mainloop()